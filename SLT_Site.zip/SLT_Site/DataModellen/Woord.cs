﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataModellen
{
    public class Woord
    {
        public string Begrip { get; set; }
        public string Betekenis { get; set; }
    }
}
