﻿
namespace DataModellen
{
    public class Admin : User
    {
        public Admin() : base(isadmin: true)
        {

        }
    }
}
