﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataModellen
{
    public class Gebruiker : User
    {
        public Gebruiker() : base(false)
        {

        }
    }
}
