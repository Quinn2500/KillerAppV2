﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DataModellen;
using Newtonsoft.Json.Serialization;

namespace SLT_Site.Models.Overhoren
{
    public class StartOverhoringModel
    {
        public Overhoring Overhoring { get; set; }

        public string Jsonstring { get; set; }
    }
}
