﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DataModellen;

namespace SLT_Site.Models.Dashboard
{
    public class ListOverviewModel
    {
       public Lijst Lijstje = new Lijst();
    }
}
