﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DataModellen;

namespace SLT_Site.Models.Dashboard
{
    public class PublicListModel
    {
        public List<Lijst> PublicLists = new List<Lijst>();
        public List<Lijst> ApprovedLists = new List<Lijst>();
    }
}
