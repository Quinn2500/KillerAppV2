﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SLT_Site.Models.Dashboard
{
    public class DashboardModel
    {
        public List<string> Lijsten = new List<string>();
    }
}
